#pragma once

Class Lamp